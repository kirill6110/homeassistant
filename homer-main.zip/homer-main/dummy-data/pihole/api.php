{
	"domains_being_blocked": 152588,
	"dns_queries_today": 0,
	"ads_blocked_today": 0,
	"ads_percentage_today": 42,
	"unique_domains": 0,
	"queries_forwarded": 0,
	"queries_cached": 0,
	"clients_ever_seen": 0,
	"unique_clients": 0,
	"dns_queries_all_types": 0,
	"reply_UNKNOWN": 0,
	"reply_NODATA": 0,
	"reply_NXDOMAIN": 0,
	"reply_CNAME": 0,
	"reply_IP": 0,
	"reply_DOMAIN": 0,
	"reply_RRNAME": 0,
	"reply_SERVFAIL": 0,
	"reply_REFUSED": 0,
	"reply_NOTIMP": 0,
	"reply_OTHER": 0,
	"reply_DNSSEC": 0,
	"reply_NONE": 0,
	"reply_BLOB": 0,
	"dns_queries_all_replies": 0,
	"privacy_level": 0,
	"status": "enabled",
	"gravity_last_updated": {
		"file_exists": true,
		"absolute": 1665486627,
		"relative": {
			"days": 0,
			"hours": 0,
			"minutes": 22
		}
	}
}