# Inspiration and resources


https://www.st.com/content/ccc/resource/technical/document/user_manual/group1/fc/c3/0b/8c/0c/da/4c/8d/DM00600212/files/DM00600212.pdf/jcr:content/translations/en.DM00600212.pdf

https://www.youtube.com/watch?v=c91Ve-g0J2U

https://www.st.com/content/ccc/resource/technical/document/user_manual/group1/df/1d/a8/2e/35/28/47/64/DM00626942/files/DM00626942.pdf/jcr:content/translations/en.DM00626942.pdf

https://forum.arduino.cc/index.php?topic=621855.0

"I managed to get much better results with these ROI(Region of Interest)/zone settings: Width=8, Height=8, opticalCentre[] = {167, 223}"

Andrea Fox's arduino sketch which adds mqtt to the existing Sparkfun amd ST code.
https://github.com/Andrea-Fox/peopleCounter

**Esphome components** <br/>
Esphome official component for the vl53l0x as distance sensor
https://github.com/esphome/esphome/tree/dev/esphome/components/vl53l0x

**Libraries** <br/>
Sparkfun VL53L1X library
https://github.com/sparkfun/SparkFun_VL53L1X_Arduino_Library

Pololu VL53L1X library used by ESPHOME PR #1447 https://github.com/esphome/esphome/pull/1447 <br/>
https://github.com/pololu/vl53l1x-arduino
