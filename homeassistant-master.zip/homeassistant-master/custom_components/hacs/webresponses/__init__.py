"""Initialize HACS Web responses"""
