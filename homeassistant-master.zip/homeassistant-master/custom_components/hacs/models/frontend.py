"""HacsFrontend."""


class HacsFrontend:
    """HacsFrontend."""

    version_running: bool = None
    version_available: bool = None
    version_expected: bool = None
    update_pending: bool = False
